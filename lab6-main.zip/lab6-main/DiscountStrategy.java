public interface DiscountStrategy {
    double calculateDiscount(Product product, int quantity);
}